const config = require('../../botconfig/config.json');
const eec = require('../../botconfig/embed.json');
const {
    MessageEmbed,
    MessageActionRow,
    MessageSelectMenu,
    MessageButton
} = require('discord.js');

module.exports = {
  name: "help",
  description: "Shows you information for evey commands",
  cooldown: 10,
  userPermissions: [],
  botPermissions: [],

  run: async (client, interaction, args, ee, prefix) => {
    try {
        const embed = new MessageEmbed()
        .setColor(ee.color)
        .setImage(eec.gif)
        .setFooter("Page Overview\n" + client.user.username, client.user.displayAvatarURL())
        .setAuthor(`${client.user.username} Help Menu`, client.user.displayAvatarURL())
        // .setTitle(`<:setting:901790652768079922> ${client.user.username} Help Menu`)
        .addFields([{
            name: `<:M_Category:923142056342347786> **Categories**`,
            value: `>>> <:M_y:905814084363112548> **[Overview](${process.env.WEBSITE})
🔰 [Information](${process.env.WEBSITE})
<:M_music:919059393268572202> [Music](${process.env.WEBSITE})
💪 [Setup](${process.env.WEBSITE})
<:M_mod:903984765638697012> [Moderation](${process.env.WEBSITE})
<:M_level:903985530218356787> [Ranking](${process.env.WEBSITE})
🕹️ [Fun](${process.env.WEBSITE})
 <:M_minigames:901781384232857630> [Mini Games](${process.env.WEBSITE})
🔨 [Utility](${process.env.WEBSITE})
<:M_report:903985507963383869> [Report](${process.env.WEBSITE})**`
        }])
        .addField(`<:M_links:923143562034577448> **Links:**`, `>>> **[Support Server](${process.env.SUPPORT}) | [Invite Me](${process.env.INVITE}) | [Dashboard](${process.env.WEBSITE})**`)

        const embed1 = new MessageEmbed()
            .setDescription(`🔰︱__**INFORMATION**__\n\n**${client.user.username} is one of the best free all in one bots that has many features like moderation, leveling, games, economy, custom commands, music and more.**\n\n>>> \`ping\`, \`help\``)
            .setColor(ee.color)
            .setImage(eec.gif)
            .setFooter(`Page 1/3 | ${client.user.username}`, ee.footericon)
            .setTimestamp()

        const embed2 = new MessageEmbed()
            .setDescription(`💪︱__**SETUP**__\n\n**${client.user.username} is one of the best free all in one bots that has many features like moderation, leveling, games, economy, custom commands, music and more.**\n\n • \`custom-command\`\n • \`backup\`\n • \`menurole-add\` | \`menurole-panel\` | \`menurole-remove\``)
            .setColor(ee.color)
            .setImage(eec.gif)
            .setFooter(`Page 2/3 | ${client.user.username}`, ee.footericon)
            .setTimestamp()
        
        const embed3 = new MessageEmbed()
            .setDescription(`🎶︱__**MUSIC**__\n\n**${client.user.username} is one of the best free all in one bots that has many features like moderation, leveling, games, economy, custom commands, music and more.**\n\n>>> \`music play\`︲\`music volume\`︲\`music skip\`︲\`music stop\`︲
\`music pause\`︲\`music resume\`︲\`music queue\`︲\`music autoplay\`︲\`music shuffle\`︲\`music loop\`︲\`music addrelatedsong\``)
            .setColor(ee.color)
            .setImage(eec.gif)
            .setFooter(`Page 3/3 | ${client.user.username}`, ee.footericon)
            .setTimestamp()

        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                .setCustomId('select')
                // .setMaxValues(2)
                // .setMinValues(1)
                .setPlaceholder('Click me to view the Help Menu Category Pages!')
                .addOptions([{
                        label: 'Overview',
                        description: 'My Overview of me!',
                        value: 'first',
                        emoji: '899930695521148929',
                    },
                    {
                        label: 'Information',
                        description: 'Commands to share Information',
                        value: 'second',
                        emoji: '🔰',
                    },
                    {
                        label: 'Setup',
                        description: 'Commands to setup Systems',
                        value: 'third',
                        emoji: '💪',
                    },
                     {
                        label: 'Music',
                        description: 'Music Commands',
                        value: 'fourth',
                        emoji: '901775606604251156',
                    },
                ]),
            )

        let supportbutton = new MessageButton()
            .setStyle("LINK")
            .setLabel("Join Support!")
            // .setEmoji('❤️')
            .setURL(process.env.SUPPORT)  

        let invitebutton = new MessageButton()
            .setStyle("LINK")
            .setLabel("Invite Me!")
            // .setEmoji('✅')
            .setURL(process.env.INVITE)

        let websitebutton = new MessageButton()
            .setStyle("LINK")
            .setLabel("Check Website!")
            // .setEmoji('🌐')
            .setURL(process.env.WEBSITE)

        const row2 = new MessageActionRow()
            .addComponents(supportbutton, invitebutton, websitebutton);

        let theMsg = await interaction.reply({
            content: 'ㅤ',
            embeds: [embed],
            components: [row2, row]
        });


        // const filter = (inter) => inter.user.id === interaction.author.id;
        const collector = interaction.channel.createMessageComponentCollector({
            filter: inter => (inter.isButton() || inter.isSelectMenu()),
            time: 100000
        })

        collector.on("collect", async (inter) => {
        //   if(inter.user.id !== interaction.author.id)
        // return inter.reply({content: `${client.allEmojis.x} **Only the one who typed ${prefix}help is allowed to react!**`, ephemeral: true})
            const value = inter.values[0]
            if (value === "first") {
                inter.reply({
                    embeds: [embed],
                    ephemeral: true
                })
            }
            if (value === "second") {
                inter.reply({
                    embeds: [embed1],
                    ephemeral: true
                })
            }
            if (value === "third") {
                inter.reply({
                    embeds: [embed2],
                    ephemeral: true
                })
            }
            if (value === "fourth") {
                inter.reply({
                    embeds: [embed3],
                    ephemeral: true
                })
            }
        })

        // collector.on("end", (d) => {
        //     theMsg.edit({
        //         content: `**This Help Menu is expired! Please retype \`${prefix}help\` to view again.**`,
        //         components: [row2]
        //     })
        // })
    } catch (error) {
      console.error(error)
    }
  }
}
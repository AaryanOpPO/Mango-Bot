const config = require('../../botconfig/config.json');
const {
    MessageEmbed
} = require('discord.js');

module.exports = {
    name: 'music',
    description: 'Music Commands',
    cooldown: 0,
    userPermissions: [],
    botPermissions: [],
    // toggleOff: true,
    options: [
        {
            name: "play",
            description: "Plays a Song",
            type: "SUB_COMMAND",
            options: [{
                name: "query",
                description: "Provide a name or a url for the song",
                type: "STRING",
                required: true
            }]
        },
        {
            name: "volume",
            description: "Changes the volume",
            type: "SUB_COMMAND",
            options: [{
                name: "percent",
                description: "Provide a volume percent between 1 and 150",
                type: "NUMBER",
                required: true
            }]
        },
        {
            name: "queue",
            description: "Shows the queue",
            type: "SUB_COMMAND",
        },
        {
            name: "skip",
            description: "Skips the current song",
            type: "SUB_COMMAND",
        },
        {
            name: "pause",
            description: "Pauses the current song",
            type: "SUB_COMMAND",
        },
        {
            name: "resume",
            description: "Resumes the current song",
            type: "SUB_COMMAND",
        },
        {
            name: "stop",
            description: "Stops the current track and leaves the channel",
            type: "SUB_COMMAND",
        },
        {
            name: "shuffle",
            description: "Shuffles the Queue",
            type: "SUB_COMMAND",
        },
        {
            name: "autoplay",
            description: "Toggle Autoplay on/off",
            type: "SUB_COMMAND",
        },
        {
            name: "loop",
            description: "Repeat the current Queue/Song/Off",
            type: "SUB_COMMAND",
        },
        {
            name: "addrelatedsong",
            description: "Stops the current song",
            type: "SUB_COMMAND",
        },
    ],

    run: async (client, interaction, args, ee) => {
        const {
            options,
            member,
            guild,
            channel
        } = interaction;
        const VoiceChannel = member.voice.channel;

        if (!VoiceChannel) return interaction.reply({
            embeds: [new MessageEmbed()
              .setColor(ee.wrongcolor)
              .setTimestamp()
              .setTitle(`${client.allEmojis.x} Please Join a Voice Channel`)],
              ephemeral: true
        });

        if (guild.me.voice.channelId && VoiceChannel.id !== guild.me.voice.channelId) return interaction.reply({
            embeds: [new MessageEmbed()
              .setColor(ee.wrongcolor)
              .setTimestamp()
              .setTitle(`I am already playing music in <#${guild.me.voice.channelId}>`)],
              ephemeral: true
        });

        try {
            switch (options.getSubcommand()) {
                case "play": {
                    client.distube.playVoiceChannel(VoiceChannel, options.getString("query"), {
                        textChannel: channel,
                        member: member
                    });
                    return interaction.reply({
                        content: `>>> ${client.allEmojis.music.searching} Searching: **${options.getString("query")}**`,
                        ephemeral: true
                    });
                }
                case "volume": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });
                    
                    const Volume = options.getNumber("percent");
                    if (Volume > 150 || Volume < 1)
                        return interaction.reply({
                            embeds: [new MessageEmbed()
                              .setColor(ee.mediancolor)
                              .setTimestamp()
                              .setTitle(`${client.allEmojis.m} Please specify a number between 1 and 150`)]
                        });

                    client.distube.setVolume(VoiceChannel, Volume);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.volume} Volume has been set to \`${Volume}\`!`)]
                    });
                }
                case "queue": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });
                    
                    const q = queue.songs.map((song, i) => `${i === 0 ? "**Playing:**" : `**${i})**`} ${song.name} - \`${song.formattedDuration}\``).join("\n")
                    
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                        .setColor(ee.color)
                        .setTitle(`${client.allEmojis.music.queue} Queue of ${interaction.guild.name}`)
                        .setDescription(`${q}`)]
                    });
                }
                case "stop": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    await queue.stop(VoiceChannel);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.stop} Stopped playing and Leaving the Voice Channel`)]
                    });
                }
                case "skip": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    await queue.skip(VoiceChannel);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.skip} Skipped to the next Song!`)]
                    });
                }
                case "pause": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    await queue.pause(VoiceChannel);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.pause} Song has been Paused!`)]
                    });
                }
                case "resume": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    await queue.resume(VoiceChannel);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.resume} Song has been resumed`)]
                    });
                }
                case "shuffle": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    await queue.shuffle(VoiceChannel);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.shuffle} Song has been shuffled`)]
                    });
                }
                case "autoplay": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    let Mode = await queue.toggleAutoplay(VoiceChannel);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.autoplay} Autoplay Mode is set to: \`${Mode ? "On" : "Off"}\``)]
                    });
                }
                case "loop": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    let Mode2 = await client.distube.setRepeatMode(queue);

                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.loop} Loop Mode is set to: \`${Mode2 = Mode2 ? Mode2 == 2 ? "Queue" : "Song" : "Off"}\``)]
                    });
                }
                case "addrelatedsong": {
                    const queue = await client.distube.getQueue(VoiceChannel);
                    if (!queue) return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.wrongcolor)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.x} There is no Song in the Queue.`)]
                    });

                    await queue.addRelatedSong(VoiceChannel);
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                          .setColor(ee.color)
                          .setTimestamp()
                          .setTitle(`${client.allEmojis.music.addrelatedsong} A Related Song has been Added.`)]
                    });
                }
            }
        } catch (e) {
            console.log(e)
            return interaction.reply({
                embeds: [new MessageEmbed()
                    .setTitle(`⛔ Error`)
                    .setDescription(`${e}`)
                ]
            })
        }

    }
}
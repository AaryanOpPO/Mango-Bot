const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const DB = require("../../models/afk");

module.exports = {
  name: 'afk',
  description: 'AFK System',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,
  options: [{
    name: 'set',
    type: 'SUB_COMMAND',
    description: 'Set to AFK',
    options: [{
      name: "status",
      description: "Set your AFK Status",
      type: 'STRING',
      required: true
    }]
  }, {
    name: 'remove',
    type: 'SUB_COMMAND',
    description: 'Remove AFK Status',
  }],

  run: async (client, interaction, args, ee) => {
    const {
      guild,
      options,
      user,
      createdTimestamp
    } = interaction;

    const Embed = new MessageEmbed()
      .setAuthor(user.tag, user.displayAvatarURL({
        dynamic: true
      }));

    const afkStatus = options.getString("status");

    try {
      switch (options.getSubcommand()) {
        case "set": {
          await DB.findOneAndUpdate({
            // GuildID: guild.id,
            UserID: user.id
          }, {
            Status: afkStatus,
            Time: parseInt(createdTimestamp / 1000)
          }, {
            new: true,
            upsert: true
          })

          Embed.setColor(ee.color).setDescription(`>>> You have Been Set to AFK\n**Status:** ${afkStatus}`);

          return interaction.reply({
            embeds: [Embed],
            ephemeral: true
          })
        }
        case "remove": {
          await DB.deleteOne({
            // GuildID: guild.id,
            UserID: user.id
          })

          Embed.setColor(ee.color).setDescription(`>>> You have Been Removed From AFK.`);

          return interaction.reply({
            embeds: [Embed],
            ephemeral: true
          })
        }
      }
    } catch (err) {
      console.log(err)
    }

  }
}
const config = require('../../botconfig/config.json');
const {
    MessageEmbed
} = require('discord.js');

module.exports = {
    name: 'set-captcha',
    description: 'Setup Captcha',
    userPermissions: ["ADMINISTRATOR"],
    botPermissions: [],
    // toggleOff: true,
    options: [{
        name: "options",
        description: "Enable / Disable Captcha System",
        type: "STRING",
        required: true,
        choices: [{
                name: "enable",
                value: "enable",
            },
            {
                name: "disable",
                value: "disable",
            },
        ]
    }, ],

    run: async (client, interaction, args, ee) => {
        const {
            options
        } = interaction;

        try {
            switch (options.getString("options")) {
                case "enable": {
                    client.captcha.set(interaction.guild.id, "captcha")
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                            .setTitle(`${client.allEmojis.y} Captcha System`)
                            .setDescription(`Captcha's is now **Enabled**`)
                            .setColor(ee.color)
                        ]
                    });
                }
                case "disable": {
                    client.captcha.delete(interaction.guild.id)
                    return interaction.reply({
                        embeds: [new MessageEmbed()
                            .setTitle(`${client.allEmojis.x} Captcha System`)
                            .setDescription(`Captcha's is now **Disabled**`)
                            .setColor(ee.wrongcolor)
                        ]
                    });
                }
            }
        } catch (e) {
            console.log(e)
            return interaction.reply({
                embeds: [new MessageEmbed()
                    .setTitle(`⛔ Error`)
                    .setDescription(`${e}`)
                ]
            })
        }
    }
}
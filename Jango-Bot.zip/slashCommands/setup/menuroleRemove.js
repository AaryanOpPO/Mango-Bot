const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const rrModel = require("../../models/menu-role")

module.exports = {
  name: 'menurole-remove',
  description: 'remove a custom MenuRole',
  cooldown: 0,
  userPermissions: ["MANAGE_ROLES"],
  botPermissions: ["MANAGE_ROLES"],
  options: [
    {
      name: "role",
      description: "role to be removed",
      type: "ROLE",
      required: true
    }
  ],

  run: async (client, interaction, args, ee) => {
    const role = interaction.options.getRole("role");

    const guildData = await rrModel.findOne({
      guildId: interaction.guildId
    })

    if (!guildData) return interaction.reply({ embeds: [new MessageEmbed()
    .setColor(ee.wrongcolor)
    .setFooter(ee.footertext, ee.footericon)
    .setTitle(`${client.allEmojis.x} MenuRole System`)
    .setDescription(`**There is no Menu Role Exist**`)]});

    const guildRoles = guildData.roles;

    const findRole = guildRoles.find((x) => x.roleId === role.id);
    if (!findRole) return interaction.reply({ embeds: [new MessageEmbed()
    .setColor(ee.wrongcolor)
    .setFooter(ee.footertext, ee.footericon)
    .setTitle(`${client.allEmojis.x} MenuRole System`)
    .setDescription(`**That role is not added to the Menu Roles List**`)]});

    const filteredRoles = guildRoles.filter((x) => x.roleId !== role.id)
    guildData.roles = filteredRoles;

    await guildData.save()

    interaction.reply({ embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setFooter(ee.footertext, ee.footericon)
    .setTitle(`${client.allEmojis.y} MenuRole System`)
    .setDescription(`Successfully Removed: **${role.name}**`)]})
  }
}
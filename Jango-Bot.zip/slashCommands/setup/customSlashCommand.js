const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const customCommandModel = require('../../models/customSlashCommands')

module.exports = {
  name: 'custom-command',
  description: 'Creates a Custom Slash Command',
  cooldown: 0,
  userPermissions: ["ADMINISTRATOR"],
  botPermissions: [],
  options: [
    {
    name: "create",
    description: "create a custom command",
    type: "SUB_COMMAND",
    options: [{
        name: "command",
        description: "name of the custom command",
        type: "STRING",
        required: true
      },
      {
        name: "response",
        description: "response for the custom command",
        type: "STRING",
        required: true
      },
    ]
  },
  {
    name: "delete",
    description: "remove the custom command",
    type: "SUB_COMMAND",
    options: [{
      name: "command",
      description: "name of the custom command",
      type: "STRING",
      required: true
    }],
  },
],

  run: async (client, interaction, args, ee) => {
    const subCommand = interaction.options.getSubcommand();
    const commandName = interaction.options.getString("command");
    const customCommand = await customCommandModel.findOne({ commandName })

    if (subCommand === "create") {
      const response = interaction.options.getString("response");
      const properties = {
        commandName,
        response,
        guildId: interaction.guildId,
      };

      if (!customCommand) {
        await customCommandModel.create(properties);
      } else {
        await customCommand.update(properties);
      }

      await interaction.guild.commands.create({ name: commandName, description: "A Custom Slash Command", })

      return interaction.reply({ embeds: [new MessageEmbed()
        .setTitle(`${client.allEmojis.y} Custom Slash Commands`)
        .setColor(ee.color)
        .addField("Command Name", commandName)
        .addField("Command Response", response)] });
    } else if (subCommand === "delete") {
      if (!customCommand) return interaction.reply({ embeds: [new MessageEmbed()
        .setTitle(`${client.allEmojis.x} That Custom Slash Command Does Not Exist`)
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)] });

      await customCommand.delete();
      const command = await interaction.guild.commands.cache.find((cmd) => cmd.name === commandName);
      // command.delete()

      await interaction.guild.commands.delete(command.id);
      return interaction.reply({ embeds: [new MessageEmbed()
        .setTitle(`${client.allEmojis.y} Custom Slash Command has been Deleted`)
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)] })
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'pull',
  aliases: [],
  usage: '',
  description: 'Pull a user to Voice Channel',
  cooldown: 0,
  userPermissions: ['MOVE_MEMBERS'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please mention a member!`)]});
      if (!member.voice.channel) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`The member you mentioned is not in the Voice Channel!`)]});

      if (!message.member.voice.channel) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please join a Voice Channel!`)]});
      member.voice.setChannel(message.member.voice.channel);
      message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Successfully Moved member!`)]});
    } catch (e) {
      console.log(e)
    }
  }
}
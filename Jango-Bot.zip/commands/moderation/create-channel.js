const config = require('../../botconfig/config.json');
const ee = require('../../botconfig/embed.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'create-channel',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['MANAGE_CHANNELS'],
  botPermissions: ['MANAGE_CHANNELS'],

  run: async (client, message, args, ee) => {
    try {
      const channelNameQuery = args.join(" ");
      if (!channelNameQuery) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`PLease specify a name for the channel!`)]})

      message.guild.channels.create(channelNameQuery).then((ch) => {
        message.reply({ embeds:[new MessageEmbed()
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`Channel has been successfully created ${ch}`)]})
      });
    } catch (e) {
      console.log(e)
    }
  },
};
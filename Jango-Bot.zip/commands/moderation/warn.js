const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const db = require('../../models/warningSchema')

module.exports = {
  name: 'warn',
  aliases: [],
  usage: "",
  description: '',
  cooldown: 0,
  userPermissions: ['KICK_MEMBERS'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const user = message.mentions.members.first() || message.guild.members.cache.get(args[0])
      if (!user) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription('Please mention the member you want to warn.')]})
      const reason = args.slice(1).join(" ")
      if (!reason) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription('Please mention a reason for the warning.')]})
      db.findOne({
        guildid: message.guild.id,
        user: user.user.id
      }, async (err, data) => {
        if (err) throw err;
        if (!data) {
          data = new db({
            guildid: message.guild.id,
            user: user.user.id,
            content: [{
              moderator: message.author.id,
              reason: reason
            }]
          })
        } else {
          const obj = {
            moderator: message.author.id,
            reason: reason
          }
          data.content.push(obj)
        }
        data.save()
      });
      message.reply({ embeds:[new MessageEmbed()
        .setDescription(`Warned ${user} for ${reason}`)
        .setFooter(ee.footertext, ee.footericon)
        .setColor(ee.color)]})
    } catch (e) {
      console.log(e)
    }
  }
}
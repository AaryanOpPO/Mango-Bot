const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'ban',
  aliases: [],
  usage: "[@user] [reason]",
  description: 'Ban Member!',
  cooldown: 0,
  userPermissions: ['BAN_MEMBERS'],
  botPermissions: ['BAN_MEMBERS'],

  run: async (client, message, args, ee) => {
    try {
      let reason = args.slice(1).join(" ");
      const mentionedMember = message.mentions.members.first();

      if (!reason) reason = 'No reason given.';
      if (!args[0]) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`You must state someone to ban.`)]});
      if (!mentionedMember) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`The member mentioned is not in the server.`)]});
      if (!mentionedMember.bannable) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`I cannot ban that member.`)]});

      await mentionedMember.send({ embeds:[new MessageEmbed()
        .setTitle(`You have been banned from ${message.guild.name}`)
        .setDescription(`Reason for being banned: ${reason}`)
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setTimestamp()]}).catch(err => console.log('I was unable to message the member.'));
      await mentionedMember.ban({
        days: 7,
        reason: reason
      }).catch(err => console.log(err)).then(() => message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription("Successfully banned " + mentionedMember.user.tag)]}));
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'fetch-bans',
  aliases: ['fetch-ban'],
  usage: "",
  description: 'Display Banned Member!',
  cooldown: 0,
  userPermissions: ['BAN_MEMBERS'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const fetchBans = message.guild.bans.fetch();
      const bannedMembers = (await fetchBans).map((member) => `\`${member.user.tag}\``).join("\n");
      message.channel.send({ embeds:[new MessageEmbed()
        .setAuthor('Banned Members List', message.guild.iconURL({
          dynamic: true
        }))
        .setThumbnail(message.guild.iconURL({
          dynamic: true
        }))
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(bannedMembers)]});
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const db = require('../../models/warningSchema')

module.exports = {
  name: 'remove-warn',
  aliases: [],
  usage: "",
  description: '',
  cooldown: 0,
  userPermissions: ['KICK_MEMBERS'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
      if (!user) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription('Please mention a member to remove the warns.')]})
      db.findOne({
        guildid: message.guild.id,
        user: user.user.id
      }, async (err, data) => {
        if (err) throw err;
        if (data) {
          let number = parseInt(args[1]) - 1
          data.content.splice(number, 1)
          message.reply({ embeds:[new MessageEmbed()
            .setColor(ee.color)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription('Successfully Removed 1 Warning for the user.')]})
          data.save()
        } else {
          message.reply({ embeds:[new MessageEmbed()
            .setColor(ee.wrongcolor)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription('This user does not have any warnings in this server!')]})
        }
      })
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'kick',
  aliases: [],
  usage: "[@user] [reason]",
  description: 'Kick Member!',
  cooldown: 0,
  userPermissions: ['KICK_MEMBERS'],
  botPermissions: ['KICK_MEMBERS'],

  run: async (client, message, args, ee) => {
    try {
      const mentionedMember = message.mentions.members.first();
      let reason = args.slice(1).join(" ");
      if (!reason) reason = "No reason given";

      // `${prefix}kick @user reason`
      if (!args[0]) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`You need to state a user to kick!`)]});
      if (!mentionedMember) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`The member mentioned is not in the server!`)]});
      try {
        await mentionedMember.send({ embeds:[new MessageEmbed()
          .setTitle(`You were kicked from ${message.guild.name}`)
          .setDescription(`Reason: ${reason}`)
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setTimestamp()
          .setFooter(client.user.tag, client.user.displayAvatarURL())]});
      } catch (err) {
        console.log('I was unable to message the member.');
      }

      try {
        await mentionedMember.kick(reason);
      } catch (err) {
        console.log(err)
        return message.reply({ embeds:[new MessageEmbed()
          .setDescription(`I was unable to kick the member mentioned.`)
          .setFooter(ee.footertext, ee.footericon)
          .setColor(ee.color)]})
      }
      message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Successfully Kicked the member!`)]});
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const db = require('../../models/warningSchema')

module.exports = {
  name: 'remove-all-warns',
  aliases: [],
  usage: "",
  description: '',
  cooldown: 0,
  userPermissions: ['KICK_MEMBERS'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
      if (!user) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription('Please mention a member to remove all the warnings.')]})
      db.findOne({
        guildid: message.guild.id,
        user: user.user.id
      }, async (err, data) => {
        if (err) throw err;
        if (data) {
          await db.findOneAndDelete({
            user: user.user.id,
            guildid: message.guild.id
          })
          message.reply({ embeds:[new MessageEmbed()
            .setColor(ee.color)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription(`Removed all the warnings for ${user.user.tag}`)]})
        } else {
          message.reply({ embeds:[new MessageEmbed()
            .setColor(ee.wrongcolor)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription(`This user does not have any warnings in this server!`)]})
        }
      })
    } catch (e) {
      console.log(e)
    }
  }
}
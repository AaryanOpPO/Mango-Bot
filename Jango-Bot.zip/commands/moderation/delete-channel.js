const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'delete-channel',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['MANAGE_CHANNELS'],
  botPermissions: ['MANAGE_CHANNELS'],

  run: async (client, message, args, ee) => {
    try {
      const channelTarget = message.mentions.channels.first()
      if (!channelTarget) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please specify a channel to delete.`)]})
      channelTarget.delete().then(async (ch) => {
        await message.author.send({ embeds:[new MessageEmbed()
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`Channel has been successfully deleted.`)]}).catch(err => console.log('I was unable to message the member.'));
      });
    } catch (e) {
      console.log(e)
    }
  },
};
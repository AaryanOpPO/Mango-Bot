const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'nuke',
  aliases: [],
  usage: '',
  description: 'Nuke Channel!',
  cooldown: 0,
  userPermissions: ['MANAGE_CHANNELS'],
  botPermissions: ['MANAGE_CHANNELS'],

  run: async (client, message, args, ee) => {
    try {
      let reason = args.join(" ");
      const nukeChannel = message.channel;

      if (!reason) reason = "No reason given.";
      if (!nukeChannel.deletable) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`This channel is not deleteable.`)]});

      await nukeChannel.clone().catch(err => console.log(err));
      await nukeChannel.delete(reason).catch(err => console.log(err));
    } catch (e) {
      console.log(e)
    }
  }
}
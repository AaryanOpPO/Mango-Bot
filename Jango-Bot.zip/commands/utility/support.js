const config = require('../../botconfig/config.json');
const eec = require('../../botconfig/embed.json');
const {
  MessageActionRow,
  MessageButton,
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'support',
  aliases: ['support-me'],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {

    let embed = new MessageEmbed()
      .setTitle(`🎟️ You need help? JOIN OUR SUPPORT SERVER`)
      .setColor(ee.color)
      .setImage(eec.gif)
      .setFooter(ee.footertext, ee.footericon)

    let supportbutton = new MessageButton()
            .setStyle("LINK")
            .setLabel("Join Support!")
            // .setEmoji('❤️')
            .setURL(process.env.SUPPORT)  

    let invitebutton = new MessageButton()
            .setStyle("LINK")
            .setLabel("Invite Me!")
            // .setEmoji('✅')
            .setURL(process.env.INVITE)

    let websitebutton = new MessageButton()
            .setStyle("LINK")
            .setLabel("Check Website!")
            // .setEmoji('🌐')
            .setURL(process.env.WEBSITE)

    const row = new MessageActionRow()
        .addComponents(supportbutton, invitebutton, websitebutton);

    return message.reply({
        embeds: [embed],
        components: [row]
    }).catch(err => console.log(err));
    
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const math = require('mathjs');

module.exports = {
  name: 'calculator',
  aliases: ['calc', 'calculate', 'math'],
  usage: '',
  description: 'Calculator!',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      try {
        message.channel.send({ embeds:[new MessageEmbed()
          .setAuthor("Calculator!", message.author.avatarURL({
            dynamic: true
          }))
          .addField('**Question**', `${args.join(" ")}`)
          .addField('**Solution**', `${math.evaluate(args.join(" "))}`)
          .setFooter(ee.footertext, ee.footericon)
          .setColor(ee.color)]});
      } catch (err) {
        message.reply({ embeds:[new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`Your question is not vaild!`)]});
      }
    } catch (e) {
      console.log(e)
    }
  },
};
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: "invites",
  aliases: [],
  usage: '',
  description: "",
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      let user = message.mentions.users.first() || message.author
      let invites = await message.guild.invites.fetch();
      let userInv = invites.filter(u => u.inviter && u.inviter.id === user.id)

      if (userInv.size <= 0) {
        return message.reply({embeds: [new MessageEmbed()
          .setColor(ee.wrongcolor)
          .setDescription(`${user} don't have any invites`)]})
      }

      let invCodes = userInv.map(x => x.code).join('\n')
      let i = 0;
      userInv.forEach(inv => i += inv.uses)

      message.reply({embeds: [new MessageEmbed()
        .setTitle(`${user.username} Invites`)
        .setDescription(`__**User Invites**__\n**${i}**\n__**Invite Codes**__\n\`${invCodes}\``)
        // .addField('User Invites', i)
        // .addField('Invite Codes', invCodes)
        .setColor(ee.color)
        .setTimestamp()]})
    } catch (e) {
      console.log(e)
    }
  }
}
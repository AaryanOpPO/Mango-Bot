const config = require('../../botconfig/config.json');
const {
  MessageEmbed,
  Util
} = require('discord.js');

module.exports = {
  name: "steal-emoji",
  aliases: ['steal-emojis', "add-emoji"],
  usage: "",
  description: "Steal Emojis from Other Servers.",
  cooldown: 0,
  userPermissions: ['USE_EXTERNAL_EMOJIS'],
  botPermissions: ["USE_EXTERNAL_EMOJIS"],

  run: async (client, message, args, ee) => {
    try {
      if (!args.length) return message.channel.send({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please specify some emojis!`)]});
      for (const rawEmoji of args) {
        const parsedEmoji = Util.parseEmoji(rawEmoji);

        if (parsedEmoji.id) {
          const extension = parsedEmoji.animated ? ".gif" : ".png";
          const url = `https://cdn.discordapp.com/emojis/${parsedEmoji.id + extension}`;
          message.guild.emojis.create(url, parsedEmoji.name).then((emoji) => message.channel.send({ embeds:[new MessageEmbed()
            .setColor(ee.color)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription(`Added: \`${emoji.url}\``)]})).catch((e) => {
              message.channel.send({ embeds: [new MessageEmbed()
              .setColor(ee.wrongcolor)
              .setFooter(ee.footertext, ee.footericon)
              .setDescription(`${client.allEmojis.x} Maximum Number of Animated Emojis Reached (50)`)]})
            })
        }
      }
    } catch (e) {
      console.log(e)
    }
  },
};
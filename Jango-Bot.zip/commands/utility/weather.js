const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const weather = require('weather-js');

module.exports = {
  name: 'weather',
  aliases: [],
  usage: '[location]',
  description: 'Check the weather status of any location!',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      if (!args[0]) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`**Please Enter A Location!**`)]})

      weather.find({
        search: args.join(" "),
        degreeType: 'C'
      }, function (err, result) {

        if (err) message.reply(err.message);

        if (result.length === 0) {
          message.reply({ embeds:[new MessageEmbed()
            .setColor(ee.wrongcolor)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription(`**Please Enter A Valid Location.**`)]})
          return undefined;
        }

        var current = result[0].current;
        var location = result[0].location;

        message.reply({ embeds:[new MessageEmbed()
          .setDescription(`**${current.skytext}**`)
          .setAuthor(`Weather for ${current.observationpoint}`)
          .setThumbnail(current.imageUrl)
          .setColor(ee.color)
          .addField('**Timezone**', `UTC ${location.timezone}`, true)
          .addField('**Degree Type**', `${location.degreetype}`, true)
          .addField('**Temperature**', `${current.temperature} Degrees`, true)
          .addField('**Feels Like**', `${current.feelslike} Degrees`, true)
          .addField('**Winds**', `${current.winddisplay}`, true)
          .addField('**Humidity**', `${current.humidity}%`, true)
          .addField('**Date**', `${current.date}`, true)
          .addField('**Day**', `${current.day}`, true)
          .setFooter(ee.footertext, ee.footericon)
          .setTimestamp()]})
      })
    } catch (e) {
      console.log(e)
    }
  }
}
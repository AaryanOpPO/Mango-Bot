const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'random-avatar',
  aliases: [],
  usage: '',
  description: 'Shows the random user avatar!',
  cooldown: 8,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const user = client.users.cache.random();

      return message.reply({ embeds:[new MessageEmbed()
        .setTitle(`${user.tag}'s Avatar`)
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setImage(user.displayAvatarURL())]});
    } catch (e) {
      console.log(e)
    }
  }
}
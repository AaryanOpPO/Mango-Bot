const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'avatar',
  aliases: [],
  usage: '@member',
  description: 'Shows the user avatar!',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.guild.members.cache.find(x => x.user.username.toLowerCase() === args.slice(0).join(' ') || x.user.username === args[0]) || message.member;
      message.reply({ embeds:[new MessageEmbed()
        .setAuthor(member.user.tag, member.displayAvatarURL({ dynamic: true, size: 4096 }))
        .addField("<a:YellowArrow:904258979432132640> PNG",`[\`LINK\`](${member.displayAvatarURL({format: "png"})})`, true)
        .addField("<a:YellowArrow:904258979432132640> JPEG",`[\`LINK\`](${member.displayAvatarURL({format: "jpg"})})`, true)
        .addField("<a:YellowArrow:904258979432132640> WEBP",`[\`LINK\`](${member.displayAvatarURL({format: "webp"})})`, true)
        .setColor(ee.color)
        .setImage(member.displayAvatarURL({ dynamic: true, size: 4096 }))
        .setThumbnail(message.guild.iconURL({
          dynamic: true
        }))
        .setFooter(`Requested By: ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()]});
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const ms = require("ms")

module.exports = {
  name: "timer",
  aliases: ['remind'],
  usage: '[time] [reason]',
  description: "Timer!",
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      let = message.content.split(" ").slice(1)

      let time = args[0];
      if (!time) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`You didn't specify a time!`)]});

      let reason = args.slice(1).join(" ");
      if (!reason) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please put the reason`)]})

      message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`✅ | Got it, I'll remind you after ${ms(ms(time))}`)]})

      setTimeout(function () {
        message.author.send({ embeds:[new MessageEmbed()
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`You asked me to remind you after ${ms(ms(time))}\nreason: ${reason}`)]});
        message.reply({ embeds:[new MessageEmbed()
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`${message.author}, You asked me to remind you after ${ms(ms(time))}\nreason: ${reason}`)]})
      }, ms(time));
    } catch (e) {
      console.log(e)
    }
  }
}
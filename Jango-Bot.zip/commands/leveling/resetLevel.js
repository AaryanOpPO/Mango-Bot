const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
  name: 'reset-level',
  aliases: ["resetlevel"],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ["MANAGE_GUILD"],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    const mentionmember = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!mentionmember) return message.reply({ embeds: [new MessageEmbed()
    .setTitle(`${client.allEmojis.m} Please mentions the member to deleted the leveling data`)
    .setColor(ee.mediancolor)] });
    try {
      await Levels.deleteUser(mentionmember.user.id, message.guild.id);
      message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.y} Successfully Deleted Leveling Database For: \`${mentionmember.user.tag}\``)
          .setColor(ee.color)]
      })
    } catch (e) {
      console.log(e)
    }
  }
}

const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
  name: 'remove-level',
  aliases: ["removelevel"],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ["MANAGE_GUILD"],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    const mentionmember = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!mentionmember) return message.reply({ embeds: [new MessageEmbed()
    .setTitle(`${client.allEmojis.m} Please mentions the member to remove Level`)
    .setColor(ee.mediancolor)] });
    const value = Number(args[1]);
    const levelUser = await Levels.fetch(mentionmember.user.id, message.guild.id);
    if (!value) return message.reply({ embeds: [new MessageEmbed()
    .setTitle(`${client.allEmojis.m} Please mention the amount of Levels you want to remove`)
    .setColor(ee.mediancolor)] });
    try {
      await Levels.subtractLevel(mentionmember.user.id, message.guild.id, value);
      message.reply({ embeds: [new MessageEmbed()
    .setTitle(`${client.allEmojis.y} Removed: **${value}** Level(s) from **${mentionmember.user.tag}**`)
    .setColor(ee.color)] })
    } catch (e){
      console.log(e)
    }
  }
}

const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
  name: 'leaderboard',
  aliases: [],
  usage: '',
  description: "Displays the servers top 5 leveled users!",
  cooldown: 10,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const rawLeaderboard = await Levels.fetchLeaderboard(message.guild.id, 5);

      if (rawLeaderboard.length < 1) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setDescription(`Nobody's in leaderboard yet!`)]});

      const leaderboard = await Levels.computeLeaderboard(client, rawLeaderboard, true);

      const lb = leaderboard.map(e => `**${e.position}. ${e.username}#${e.discriminator}**\n📊 Level: ${e.level}\n♾️ XP: ${e.xp.toLocaleString()}`);

      message.reply({ embeds:[new MessageEmbed()
        .setTitle(`📊 leaderboard for ${message.guild.name} 📊`)
        .setDescription(`${lb.join("\n\n")}`)
        .setColor(ee.color)
        .setThumbnail(message.guild.iconURL({
          dynamic: true
        }))
        .setFooter(ee.footertext, ee.footericon)
        .setTimestamp()]});
    } catch (e) {
      console.log(e)
    }
  },
};
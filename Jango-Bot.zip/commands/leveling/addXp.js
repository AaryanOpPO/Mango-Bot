const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
  name: 'add-xp',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ["MANAGE_GUILD"],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    const mentionmember = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!mentionmember) return message.reply({ embeds: [new MessageEmbed()
    .setTitle(`${client.allEmojis.m} Please mentions the member to add Xp`)
    .setColor(ee.mediancolor)] });
    const value = Number(args[1]);
    const levelUser = await Levels.fetch(mentionmember.user.id, message.guild.id);
    if (!value) return message.reply({ embeds: [new MessageEmbed()
    .setTitle(`${client.allEmojis.m} Please mention the amount of Xp you want to add to`)
    .setColor(ee.mediancolor)] });
    try {
      await Levels.appendXp(mentionmember.user.id, message.guild.id, value);
      message.reply({ embeds: [new MessageEmbed()
    .setTitle(`${client.allEmojis.y} Added: **${value}** Xp to **${mentionmember.user.tag}**`)
    .setColor(ee.color)] })
    } catch (e){
      console.log(e)
    }
  }
}

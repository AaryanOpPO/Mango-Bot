const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
  name: 'reset-level-all',
  aliases: ["resetlevelall"],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ["ADMINISTRATOR"],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      await Levels.deleteGuild(`${message.guild.id}`);
      message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.y} Successfully Deleted Leveling Database For Everyone.`)
          .setColor(ee.color)]
      })
    } catch (e) {
      console.log(e)
    }
  }
}

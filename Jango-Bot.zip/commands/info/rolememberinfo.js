const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: "rolememberinfo",
  aliases: ['r-memberinfo'],
  usage: '',
  description: "Shows List Of Members Having A Role",
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      if (args.includes("@everyone")) return;
      if (args.includes("@here")) return;
      if (!args[0]) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`${client.allEmojis.m} **Please Enter A Role!**`)]})
      let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]) || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLocaleLowerCase());
      if (!role) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`${client.allEmojis.x} **Please Enter A Valid Role!**`)]});
      let membersWithRole = message.guild.members.cache.filter(member => {
        return member.roles.cache.find(r => r.name === role.name);
      }).map(member => {
        return member.user.username;
      })
      if (membersWithRole > 2048) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`${client.allEmojis.x} **List Is Too Long!**`)]})
      message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.color)
        .setThumbnail(message.guild.iconURL())
        .setFooter(ee.footertext, ee.footericon)
        .setTitle(`${client.allEmojis.y} **Users With The ${role.name} Role!**`)
        .setDescription(membersWithRole.join("\n"))]});
    } catch (e) {
      console.log(e)
    }
  }
}
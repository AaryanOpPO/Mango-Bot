const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const moment = require('moment');

const status = {
  online: "Online",
  idle: "Idle",
  dnd: "Do Not Disturb",
  offline: "Offline/Invisible"
};

module.exports = {
  name: "whois",
  aliases: ['userinfo'],
  usage: '',
  description: "userinfo",
  cooldown: 0,
  userPermissions: ['MANAGE_MESSAGES'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      var permissions = [];
      var acknowledgements = 'None';

      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;


      if (member.permissions.has("KICK_MEMBERS")) {
        permissions.push("Kick Members");
      }

      if (member.permissions.has("BAN_MEMBERS")) {
        permissions.push("Ban Members");
      }

      if (member.permissions.has("ADMINISTRATOR")) {
        permissions.push("Administrator");
      }

      if (member.permissions.has("MANAGE_MESSAGES")) {
        permissions.push("Manage Messages");
      }

      if (member.permissions.has("MANAGE_CHANNELS")) {
        permissions.push("Manage Channels");
      }

      if (member.permissions.has("MENTION_EVERYONE")) {
        permissions.push("Mention Everyone");
      }

      if (member.permissions.has("MANAGE_NICKNAMES")) {
        permissions.push("Manage Nicknames");
      }

      if (member.permissions.has("MANAGE_ROLES")) {
        permissions.push("Manage Roles");
      }

      if (member.permissions.has("MANAGE_WEBHOOKS")) {
        permissions.push("Manage Webhooks");
      }

      if (member.permissions.has("MANAGE_EMOJIS_AND_STICKERS")) {
        permissions.push("Manage Emojis and Stickers");
      }

      if (permissions.length == 0) {
        permissions.push("No Key Permissions Found");
      }

      if (member.user.id == message.guild.ownerID) {
        acknowledgements = 'Server Owner';
      }

      message.reply({ embeds:[new MessageEmbed()
        .setDescription(`<@${member.user.id}>`)
        .setFooter(ee.footertext, ee.footericon)
        .setAuthor(`${member.user.tag}`, member.user.displayAvatarURL())
        .setColor(ee.color)
        .setFooter(`ID: ${message.author.id}`)
        .setThumbnail(member.user.displayAvatarURL())
        .setTimestamp()
        // .addField("__Status__", `${status[member.user.presence.status]}`, true)
        .addField('__Joined at__ ', `${moment(member.joinedAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, true)
        .addField('__Created On__', member.user.createdAt.toLocaleString(), true)
        .addField("__Playing__", member.presence.activities[0] ? member.presence.activities[0].state : `User isn't have a custom status!`, true)
        .addField(`\n__Roles [${member.roles.cache.filter(r => r.id !== message.guild.id).map(roles => `\`${roles.name}\``).length}]__`, `${member.roles.cache.filter(r => r.id !== message.guild.id).map(roles => `<@&${roles.id }>`).join(" **|** ") || "No Roles"}`, true)
        .addField("\n__Acknowledgements__ ", `${acknowledgements}`, true)
        .addField("\n__Permissions__ ", `${permissions.join(` | `)}`)]});
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'eco-coinflip',
  aliases: ["cf"],
  usage: '',
  description: '',
  cooldown: 10,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    var flip = args[0] //Heads or Tails
    var amount = Number(args[1]); //Coins to gamble
 
    if (!flip || !['heads', 'tails'].includes(flip)) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Please specify the flip, either \`heads\` or \`tails\`!`)]});

    if (!amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Specify the amount you want to gamble!`)]});
 
    var output = await eco.FetchBalance(message.author.id)
    if (output.balance < amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.wrongcolor)
    .setDescription(`You have fewer coins than the amount you want to gamble!`)]});
 
    var gamble = await eco.Coinflip(message.author.id, flip, amount).catch(console.error)
    message.reply({embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setDescription(`You **${gamble.output}**! New balance: **${gamble.newbalance}**`)]});
  }
}
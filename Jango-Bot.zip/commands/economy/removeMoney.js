const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'remove-money',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  ownerOnly: true,
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    var user = message.mentions.users.first()
    var amount = Number(args[1]);
  
    if (!user) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Please specify the user you want to remove money from!`)]});
    if (!amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Specify the amount you want to remove!`)]});
 
    var transfer = await eco.SubtractFromBalance(user.id, amount)
    message.reply({embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setDescription(`Successfully Removed Coin!\nBalance from **${user.tag}**: **${transfer.newbalance}**`)]});
  }
}
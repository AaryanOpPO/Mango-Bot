const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'daily',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    const randomAmountOfEco = Math.floor(Math.random() * 1000) + 1;
    var output = await eco.Daily(message.author.id)
    if (output.updated) {
 
      var profile = await eco.AddToBalance(message.author.id, randomAmountOfEco)
      message.reply({embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setDescription(`You claimed your daily coins successfully! You now own **${profile.newbalance}** coins.`)]});
 
    } else {
      message.reply({embeds: [new MessageEmbed()
    .setColor(ee.wrongcolor)
    .setDescription(`Sorry, you already claimed your daily coins!\nBut no worries, after **${output.timetowait}** you can daily again!`)]});
    }
  }
}
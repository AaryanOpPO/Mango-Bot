const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'pay',
  aliases: ["transfer", "give-coins"],
  usage: '',
  description: '',
  cooldown: 5,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    var user = message.mentions.users.first()
    var amount = Number(args[1])
  
    if (!user) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Please specify the user you want to send money to!`)]});
    if (!amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Specify the amount you want to pay!`)]});
    var output = await eco.FetchBalance(message.author.id)
    if (output.balance < amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.wrongcolor)
    .setDescription(`You have fewer coins than the amount you want to transfer!`)]});
 
    var transfer = await eco.Transfer(message.author.id, user.id, amount)
    message.reply({embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setDescription(`Successfully Transfered Coin!\nBalance from **${message.author.tag}**: **${transfer.FromUser}**\nBalance from **${user.tag}**: **${transfer.ToUser}**`)]});
  }
}
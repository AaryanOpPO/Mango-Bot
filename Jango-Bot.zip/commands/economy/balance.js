const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'balance',
  aliases: ['bal', 'cash', "money", "coin"],
  usage: '',
  description: '',
  cooldown: 5,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    const target = message.mentions.users.first() || message.author;
    
    var output = await eco.FetchBalance(target.id)
    if (output) {
      message.reply({embeds: [new MessageEmbed()
      .setColor(ee.color)
      .setDescription(`${client.allEmojis.currency.coin} | **${target.tag}**, you currently have __**${output.balance}**__ coins.`)]});
    } else {
      return message.reply({embeds: [new MessageEmbed()
      .setColor(ee.color)
      .setDescription(`${client.allEmojis.currency.coin} | **${target.tag}**, you currently have **0** coins.`)]});
    }
  }
}
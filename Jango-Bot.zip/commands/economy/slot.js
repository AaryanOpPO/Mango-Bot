const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'slot',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 10,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    var amount = Number(args[0])
 
    if (!amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Specify the amount you want to gamble!`)]});
 
    var output = await eco.FetchBalance(message.author.id)
    if (output.balance < amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.wrongcolor)
    .setDescription('You have fewer coins than the amount you want to gamble!')]});
 
    var gamble = await eco.Slots(message.author.id, amount, {
      width: 3,
      height: 1
    }).catch(console.error)
    // message.reply({embeds: [new MessageEmbed()
    // .setColor(ee.color)
    // .setTitle(`\`__SLOTS__\``)
    // .addField(`${gamble.grid.map((gamble) => `\n${gamble}`)}`, `>>> You **${gamble.output}**! New balance: **${gamble.newbalance}**`)]});
    message.reply({content: `\`__SLOTS__\`\n\`${gamble.grid.map((gamble) => `${gamble}`)}\`\nYou **${gamble.output}**! New balance: **${gamble.newbalance}**`})
    }
    }
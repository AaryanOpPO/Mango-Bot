const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'dice',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 10,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    var roll = args[0]
    var amount = Number(args[1]);

    if (!roll || ![1, 2, 3, 4, 5, 6].includes(parseInt(roll))) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Specify the roll, it should be a number between 1-6`)]});
    if (!amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Specify the amount you want to gamble!`)]});

    var output = eco.FetchBalance(message.author.id)
    if (output.balance < amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.wrongcolor)
    .setDescription(`You have fewer coins than the amount you want to gamble!`)]});

    var gamble = await eco.Dice(message.author.id, roll, amount).catch(console.error)
    message.reply({embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setDescription(`The dice rolled **${gamble.dice}**. So you **${gamble.output}**! New balance: **${gamble.newbalance}**`)]});
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'add-money',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  ownerOnly: true,
  // toggleOff: true,

  run: async (client, message, args, ee) => {
    var user = message.mentions.users.first()
    var amount = Number(args[1]);
  
    if (!user) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Plesae mention the user you want to add money to!`)]});
    if (!amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription(`Specify the amount you want to add!`)]});
 
    var transfer = await eco.AddToBalance(user.id, amount)
    message.reply({embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setDescription(`Successfully Added Coin!\nBalance from **${user.tag}**: **${transfer.newbalance}**`)]});
  }
}
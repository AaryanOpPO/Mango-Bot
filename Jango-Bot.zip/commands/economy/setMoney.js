const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const eco = require("discord-economy");

module.exports = {
  name: 'set-money',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  ownerOnly: true,
  // toggleOff: true,

  run: async (client, message, args, eec) => {
    var user = message.mentions.users.first()
    var amount = Number(args[1]);
  
    if (!user) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription('Please specify the user you want to set money to!')]});
    if (!amount) return message.reply({embeds: [new MessageEmbed()
    .setColor(ee.mediancolor)
    .setDescription('Specify the amount you want to set!')]});
 
    var transfer = await eco.SetBalance(user.id, amount)
    message.reply({embeds: [new MessageEmbed()
    .setColor(ee.color)
    .setDescription(`Successfully Setted Coin!\nBalance from **${user.tag}**: **${transfer.balance}**`)]});
  }
}
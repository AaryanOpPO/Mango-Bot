const config = require('../../botconfig/config.json');
const {
    MessageEmbed
} = require('discord.js');
const roleData = require("../../models/autorole")

module.exports = {
    name: 'remove-autorole',
    aliases: [],
    usage: '',
    description: '',
    cooldown: 0,
    userPermissions: ["MANAGE_ROLES"],
    botPermissions: ["MANAGE_ROLES"],

    run: async (client, message, args, ee) => {
        try {
            const data = client.autorole.get(message.guild.id, "autorole");
            if (!data) return message.reply({
                embeds: [new MessageEmbed()
                    .setTitle(`${client.allEmojis.x} AutoRole System`)
                    .setDescription(`**AutoRole** isn't setup!`)
                    .setColor(ee.color)
                ]
            })

            client.autorole.delete(message.guild.id, "autorole")
            message.reply({
                embeds: [new MessageEmbed()
                    .setTitle(`${client.allEmojis.y} AutoRole System`)
                    .setDescription(`**AutoRole** has been stopped!`)
                    .setColor(ee.color)
                ]
            })
        } catch (e) {
            console.log(e)
        }
    }

}
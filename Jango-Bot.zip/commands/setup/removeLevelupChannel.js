const config = require('../../botconfig/config.json');
const ee = require('../../botconfig/embed.json');
const {
  MessageEmbed
} = require('discord.js');
const Schema = require('../../models/levelToggleSchema');

module.exports = {
  name: 'remove-levelupchannel',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      Schema.findOneAndDelete({
        Guild: message.guild.id
      }, async (err, data) => {

        if (!data) return message.reply({ embeds:[new MessageEmbed()
          .setTitle(`${client.allEmojis.x} Levelup System`)
          .setColor(ee.wrongcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`No Levelup Channel`)]})
        message.reply({ embeds:[new MessageEmbed()
          .setTitle(`${client.allEmojis.y} Levelup System`)
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`**Levelup Channel** has successfully Removed`)]});
      })
    } catch (e) {
      console.log(e)
    }
  }
}
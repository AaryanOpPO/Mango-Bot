const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const schema = require('../../models/custom-commands');

module.exports = {
  name: "list-command",
  aliases: [],
  usage: "",
  description: "",
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      schema.findOne({
        Guild: message.guild.id
      }, async (err, data) => {
        if (!data) return message.channel.send({ embeds:[new MessageEmbed()
          .setTitle(`${client.allEmojis.x} Custom Command System`)
          .setColor(ee.wrongcolorcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription('There is no custom commands for this server!')]});
        const data2 = await schema.find({
          Guild: message.guild.id
        });
        message.channel.send({ embeds:[new MessageEmbed()
          .setTitle(`${client.allEmojis.y} Custom Command System`)
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(
            data2.map((cmd, i) =>
              `${i + 1}: ${cmd.Command} => ${cmd.Response}`
            ).join('\n')

          )
        ]})

      })
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Schema = require('../../models/welcomeSchema');

module.exports = {
  name: 'remove-welcomechannel',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const data = client.welcomeLeaveSystem.get(message.guild.id, "welcome");

      if (!data) return message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.x} Welcome System`)
          .setColor(ee.wrongcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`No Welcome Channel`)
        ]
      })

      client.welcomeLeaveSystem.delete(message.guild.id, "welcome");
      message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.y} Welcome System`)
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`**Welcome Channel** has successfully Removed`)
        ]
      });
    } catch (e) {
      console.log(e)
    }
  }
}
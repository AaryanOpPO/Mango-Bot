const config = require('../../botconfig/config.json');
const {
    MessageEmbed
} = require('discord.js');

module.exports = {
    name: 'set-autonick',
    aliases: [],
    usage: '',
    description: '',
    cooldown: 0,
    userPermissions: ["MANAGE_NICKNAMES"],
    botPermissions: ["MANAGE_NICKNAMES"],

    run: async (client, message, args, ee, prefix) => {
        try {
            let autonick = args.join(" ")

            if (!autonick) return message.reply({
                embeds: [new MessageEmbed()
                    .setTitle(`${client.allEmojis.m} AutoNick System`)
                    .setColor(ee.mediancolor)
                    .setDescription(`Please supply a Nickname!\nIf you want to replace the username use \`{username}\`\n\nEg: \`${prefix}set-autonick Milanio {username}\``)
                ]
            })

                client.autonick.set(message.guild.id, autonick, "autonick")
                message.reply({
                    embeds: [new MessageEmbed()
                        .setTitle(`${client.allEmojis.y} AutoNick System`)
                        .setColor(ee.color)
                        .setFooter(ee.footertext, ee.footericon)
                        .setDescription(`Successfully set **AutoNick** to \`${autonick}\``)
                    ]
                });
        } catch (err) {
            console.log(err)
        }
    }
}
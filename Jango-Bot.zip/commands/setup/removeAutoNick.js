const config = require('../../botconfig/config.json');
const {
    MessageEmbed
} = require('discord.js');

module.exports = {
    name: 'remove-autonick',
    aliases: [],
    usage: '',
    description: '',
    cooldown: 0,
    userPermissions: ["MANAGE_NICKNAMES"],
    botPermissions: ["MANAGE_NICKNAMES"],

    run: async (client, message, args, ee) => {
        try {
            const data = client.autonick.get(message.guild.id, "autonick");

            if (!data) return message.reply({
                embeds: [new MessageEmbed()
                    .setTitle(`${client.allEmojis.x} Welcome System`)
                    .setColor(ee.wrongcolor)
                    .setFooter(ee.footertext, ee.footericon)
                    .setDescription(`No Welcome Channel`)
                ]
            })

            client.autonick.delete(message.guild.id, "autonick")
            return message.reply({
                embeds: [new MessageEmbed()
                    .setTitle(`${client.allEmojis.y} AutoNick System`)
                    .setColor(ee.color)
                    .setFooter(ee.footertext, ee.footericon)
                    .setDescription(`Successfully Removed **Auto-Nick**.`)
                ]
            })
        } catch (err) {
            console.log(err)
        }
    }
}
const config = require('../../botconfig/config.json');
const schema = require('../../models/custom-commands');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'create-command',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const name = args[0];
      const response = args.slice(1).join(" ");

      if (!name) return message.channel.send({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.m} Custom Command System`)
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please specify a name for custom command`)]});
      if (!response) return message.channel.send({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.m} Custom Command System`)
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please specify a response for custom command`)]});

      const data = await schema.findOne({
        Guild: message.guild.id,
        Command: name
      });
      if (data) return message.channel.send({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.m} Custom Command System`)
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`This custom command already exists!`)]});
      const newData = new schema({
        Guild: message.guild.id,
        Command: name,
        Response: response
      })
      await newData.save();
      message.channel.send({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.y} Custom Command System`)
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Successfully added **${name}** as a **Custom Command**`)]});
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const schema = require('../../models/custom-commands');

module.exports = {
  name: 'delete-command',
  aliases: [],
  usage: "",
  description: "",
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const name = args[0];

      if (!name) return message.channel.send({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.m} Custom Command System`)
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription('Please specify a command name')]});

      const data = await schema.findOne({
        Guild: message.guild.id,
        Command: name
      });
      if (!data) return message.channel.send({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.x} Custom Command System`)
        .setColor(ee.wrongcolorcolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription('That custom command does not exist!')]});
      await schema.findOneAndDelete({
        Guild: message.guild.id,
        Command: name
      });
      message.channel.send({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.y} Custom Command System`)
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Successfully Removed **${name}** from **Custom Commands**.`)]});
    } catch (e) {
      console.log(e)
    }
  }
}
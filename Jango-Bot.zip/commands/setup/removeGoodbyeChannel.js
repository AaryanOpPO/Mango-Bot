const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Schema = require('../../models/goodbyeSchema');

module.exports = {
  name: 'remove-goodbyechannel',
  aliases: ["remove-leavechannel"],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const data = client.welcomeLeaveSystem.get(message.guild.id, "goodbye");

      if (!data) return message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.x} Goodbye System`)
          .setColor(ee.wrongcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`No Goodbye Channel`)
        ]
      })

      client.welcomeLeaveSystem.delete(message.guild.id, "goodbye");
      message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.y} Goodbye System`)
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`**Goodbye Channel** has successfully Removed`)
        ]
      });
    } catch (e) {
      console.log(e)
    }
  }
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const schema = require('../../models/levelToggleSchema');

module.exports = {
  name: 'level-toggle',
  aliases: ['lvl-t'],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      schema.findOne({
        guildId: message.guild.id
      }, async (e, data) => {
        if (!data) {
          new schema({
            guildId: message.guild.id,
            toggle: 1,
          }).save();
          return message.reply({ embeds:[new MessageEmbed()
            .setTitle(`${client.allEmojis.y} Leveling System`)
            .setColor(ee.color)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription(`**Level Toggle** is now: **on**`)]});
        };

        if (data.toggle == 1) {
          data.toggle -= 1;
          data.save();
          return message.reply({ embeds:[new MessageEmbed()
            .setTitle(`${client.allEmojis.y} Leveling System`)
            .setColor(ee.color)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription(`**Level Toggle** is now: **off**`)]});
        } else if (data.toggle == 0) {
          data.toggle += 1;
          data.save();
          return message.reply({ embeds:[new MessageEmbed()
            .setTitle(`${client.allEmojis.y} Leveling System`)
            .setColor(ee.color)
            .setFooter(ee.footertext, ee.footericon)
            .setDescription(`**Level Toggle** is now: **on**`)]});
        }
      })
    } catch (e) {
      console.log(e)
    }
  }
}
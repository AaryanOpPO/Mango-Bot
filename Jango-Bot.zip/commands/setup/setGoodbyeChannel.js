const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'set-goodbyechannel',
  aliases: ["set-leavechannel"],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee, prefix) => {
    try {
    const channel = message.mentions.channels.first();
      if (!channel) return message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.m} Goodbye System`)
          .setColor(ee.mediancolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`Please mention a channel!`)
        ]
      });

      const Welimage = args[1];
      if (!Welimage) return message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.m} Goodbye System`)
          .setColor(ee.mediancolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`Please mention a custom goodbye image url!`)
        ]
      });

    //   if (Welimage.attachments.size > 0) {
    //     if (Welimage.attachments.every(attachIsImage)){

    //       message.reply("Successfully, set your Background Image! Please make sure to **not** delete your Image from the Channel!")
    //       // client.setups.set(message.guild.id, url, "leave.background.image")
    //     }
    //     else{
    //      message.reply("Could not your message as a backgroundimage")
    //  }
    //   }
       if (Welimage.includes("https") || Welimage.includes("http")){
         
       }
      else{
        return message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.m} Goodbye System`)
          .setColor(ee.mediancolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`Please mention a valid custom goodbye image url!`)
        ]
      });
      }

      const Welmsg = args.slice(2).join(" ");
      if (!Welmsg) return message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.m} Goodbye System`)
          .setColor(ee.mediancolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`Please mention a custom goodbye message!\nIf you want to mentions the user use \`{user}\`\n If you want to display user's username use \`{username}\`\nIf you want to displays server name use \`{server}\`\nIf you want to displays member count of the server use \`{membercount}\`\n\nEg: \`${prefix}set-goodbyechannel #channel Goodbye {user}, to **{server}**, Now we have **{membercount} Members**\``)
        ]
      });

      client.welcomeLeaveSystem.set(message.guild.id, {
        channel: channel.id,
        message: Welmsg,
        background: Welimage
      }, "goodbye")

      message.reply({
        embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.y} Goodbye System`)
          .setColor(ee.color)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`${channel} has been set as the **Goodbye Channel**\n**Goodbye Message** is \`${Welmsg}\``)
        ]
      });
    } catch (e) {
      console.log(e)
    }
  }
}

function attachIsImage(msgAttach) {
  url = msgAttach.url;

  //True if this url is a png image.
  return url.indexOf("png", url.length - "png".length /*or 3*/ ) !== -1 ||
    url.indexOf("jpeg", url.length - "jpeg".length /*or 3*/ ) !== -1 ||
    url.indexOf("jpg", url.length - "jpg".length /*or 3*/ ) !== -1;
}
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const Schema = require('../../models/levelToggleSchema');

module.exports = {
  name: 'set-levelupchannel',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: ['ADMINISTRATOR'],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const channel = message.mentions.channels.first();
      if (!channel) return message.reply({ embeds:[new MessageEmbed()
        .setTitle(`${client.allEmojis.m} Levelup System`)
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`Please mention a channel!`)]});

      Schema.findOne({
        Guild: message.guild.id
      }, async (err, data) => {
        if (data) {
          data.channel = channel.id,
          data.save();
        } else {
          new Schema({
            guildId: message.guild.id,
            channel: channel.id,
          }).save();
        }
        message.reply({ embeds:[new MessageEmbed()
          .setColor(ee.color)
          .setTitle(`${client.allEmojis.y} Levelup System`)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`${channel} has been set as the Levelup Channel`)]});
      })
    } catch (e) {
      console.log(e)
    }
  }
}
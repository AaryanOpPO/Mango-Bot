const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: "howgay",
  aliases: [],
  usage: "howgay <Mention Member>",
  description: "Shows How Member Gay Is!",
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, eec) => {
    try {
      let Member =
        message.mentions.users.first() ||
        message.author;
      let Result = Math.floor(Math.random() * 101);
      message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.color)
        .setFooter(ee.footertext, ee.footericon)
        .setTitle(`About your Gayness`)
        .setDescription(`**${Member.username} Is ${Result}% Gay 🏳️‍🌈**`)
        .setTimestamp()]});
    } catch (e) {
      console.log(e)
    }
  }
};
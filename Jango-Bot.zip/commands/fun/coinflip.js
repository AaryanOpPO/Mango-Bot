const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: "coinflip",
  aliases: ['coin', 'flip'],
  usage: 'coinflip',
  description: 'flips a coin',
  cooldown: 5,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, eec) => {
    try {
      const n = Math.floor(Math.random() * 2);
      let result;
      if (n === 1) result = 'Heads';
      else result = 'Tails';
      message.reply({ embeds:[new MessageEmbed()
        .setFooter(ee.footertext, ee.footericon)
        .setColor(ee.color)
        .setDescription(`${client.allEmojis.y} **${message.member.displayName} Flipped ${result}**!`)]});
    } catch (e) {
      console.log(e)
    }
  }
};
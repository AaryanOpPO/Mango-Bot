const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const figlet = require("figlet");

module.exports = {
  name: "ascii",
  aliases: [],
  usage: "ascii <name>",
  description: "Create a ascii",
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      if (!args[0]) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`${client.allEmojis.m} **Please provide some text**`)]});
      msg = args.join(" ");
      figlet.text(msg, function (err, data) {
        if (err) {
          console.log('Something went wrong');
          console.dir(err);
        }
        if (data.length > 2000) return message.reply({ embeds:[new MessageEmbed()
          .setColor(ee.wrongcolorcolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`${client.allEmojis.x} **Please provide text shorter than 2000 characters**`)]})
        message.reply('```' + data + '```');
      });
    } catch (e) {
      console.log(e)
    }
  }
};
const config = require('config.json');
const {
  MessageAttachment,
  MessageEmbed
} = require('discord.js');
const canvacord = require('canvacord');

module.exports = {
  name: 'comment',
  aliases: [],
  usage: '<text>',
  description: 'Shows your text as a Youtube Comment',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      const comment = args.join('');
      if (!comment) return message.reply({ embeds:[new MessageEmbed()
        .setColor("BLUE")
        .setFooter("Devs Team")
        .setDescription(` **Provide something to Comment!**`)]})
      try {
        let yt = await canvacord.Canvas.youtube({
          "avatar": message.author.displayAvatarURL({
            format: "png"
          }),
          "username": message.author.username,
          "content": args.join(" ")
        })
        let attachment = new MessageAttachment(yt, 'comment.png')
        message.reply({ files: [attachment]});
      } catch (err) {
        message.reply({ embeds:[new MessageEmbed()
          .setFooter(ee.footertext, ee.footericon)
          .setTitle(`**Something went wrong.**\n**Note : It won't work if the User contains Unwanted characters in his Username.**`)
          .setColor(ee.wrongcolor)]});
      }
    } catch (e) {
      console.log(e)
    }
  }
};
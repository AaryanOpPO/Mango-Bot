const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const axios = require('axios')

module.exports = {
  name: "binary",
  aliases: [],
  usage: "",
  description: "",
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, ee) => {
    try {
      if (!args[0]) return message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.mediancolor)
        .setFooter(ee.footertext, ee.footericon)
        .setDescription(`${client.allEmojis.m} **Please specify whether you want to \`encode\` or \`decode\`**`)]});

      const query = args.shift();
      let word = args.join(" ");

      if (query === 'encode') {
        if (!word) return message.reply({ embeds:[new MessageEmbed()
          .setFooter(ee.footertext, ee.footericon)
          .setColor(ee.mediancolor)
          .setDescription(`${client.allEmojis.m} **Please specify a word to encode**`)]});
        const {
          data
        } = await axios.get(`https://some-random-api.ml/binary?text=${encodeURIComponent(word)}`);

        message.reply({ embeds:[new MessageEmbed()
          .setFooter(ee.footertext, ee.footericon)
          .setTitle(`Encoded`)
          .setColor(ee.color)
          .setDescription(data.binary ?? 'Ann error occured', {
            code: "",
          })]})
      } else if (query === 'decode') {
        if (!word) return message.reply({ embeds:[new MessageEmbed()
          .setColor(ee.mediancolor)
          .setFooter(ee.footertext, ee.footericon)
          .setDescription(`${client.allEmojis.m} **Please specify a word to decode**`)]});
        const {
          data
        } = await axios.get(`https://some-random-api.ml/binary?decode=${encodeURIComponent(word)}`);

        message.reply({ embeds:[new MessageEmbed()
          .setFooter(ee.footertext, ee.footericon)
          .setTitle(`Decoded`)
          .setColor(ee.color)
          .setDescription(data.text ?? 'Ann error occured', {
            code: "",
          })]})
      } else return message.reply({ embeds:[new MessageEmbed()
        .setFooter(ee.footertext, ee.footericon)
        .setColor(ee.wrongcolor)
        .setDescription(`${client.allEmojis.m} **Please specify a valid option.**`)]});
    } catch (e) {
      console.log(e)
    }
  },
};
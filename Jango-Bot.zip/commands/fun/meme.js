const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const axios = require('axios');

module.exports = {
  name: 'meme',
  aliases: [],
  usage: 'memes',
  description: 'Get some cool memes :)',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],

  run: async (client, message, args, eec) => {
    try {
      const url = 'https://some-random-api.ml/meme';

    let data, response;
    try {
      response = await axios.get(url);
      data = response.data;
    } catch (e) {
      return message.channel.send({ embeds: [new MessageEmbed()
      .setColor(ee.wrongcolor)
      .setTitle(`${client.allEmojis.x} **An error has occured, try again!**`)]})
    }

      await message.reply({ embeds:[new MessageEmbed()
      .setTitle(`${client.allEmojis.y} Random Meme:`)
      .setDescription(data.caption)
      .setColor(ee.color)
      .setImage(data.image)]});
    } catch (e) {
      console.log(e)
    }
  }
};
const config = require('../../botconfig/config.json');
const {
  MessageEmbed
} = require('discord.js');
const glob = require('glob');

module.exports = {
  name: 'restart-bot',
  aliases: [],
  usage: '',
  description: 'Shutdown the bot',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  ownerOnly: true,

  run: async (client, message, args, ee) => {
    try {
      await message.reply({ embeds:[new MessageEmbed()
        .setColor(ee.wrongcolor)
        .setTitle(`Bot is Restarting...`)]});
        process.exit();
    } catch (e) {
      message.channel.send({content: `Error: ${e.message}`})
    }
  },
};
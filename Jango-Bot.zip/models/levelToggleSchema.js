const mongoose = require('mongoose');

const levelToggleSchema = new mongoose.Schema({
    guildId: String,
    toggle: Number,
    channel: String,
});

module.exports = new mongoose.model('levelToggle', levelToggleSchema);
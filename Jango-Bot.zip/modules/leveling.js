const config = require('../botconfig/config.json');
const {
    MessageEmbed
} = require('discord.js');
const Discord = require("discord.js");
const {
    databasing
} = require(`../handlers/functions`);
const fetch = require('node-fetch');
const Levels = require('discord-xp');
Levels.setURL(`${process.env.MongoDB_TOKEN}`);
const lvlSchema = require('../models/levelToggleSchema');

module.exports = function (client, options) {
    const description = {
        name: "LevelingSystem",
    }
    client.logger(`〢 Module: Loaded ${description.name}`.bold.green);

    client.on("messageCreate", async (message) => {
        try {
            if (!message.guild) return;
            if (!message.channel) return;
            if (message.author.bot) return;
    
            databasing(client, message.guild.id)
            const guild_settings = client.settings.get(message.guild.id);
    
            let ee = guild_settings.embed;
    
            if (!message.guild.me.permissions.has(Discord.Permissions.FLAGS.SEND_MESSAGES)) return;
            if (!message.guild.me.permissions.has(Discord.Permissions.FLAGS.USE_EXTERNAL_EMOJIS)) return;
            if (!message.guild.me.permissions.has(Discord.Permissions.FLAGS.EMBED_LINKS)) return;
    
            lvlSchema.findOne({
                guildId: message.guild.id
            }, async (e, data) => {
                if (!data) {
                    new lvlSchema({
                        guildId: message.guild.id,
                        toggle: 1,
                    }).save();
                    return;
                };
    
                if (data.toggle == 1) {
                    const randomAmountOfXp = Math.floor(Math.random() * 19) + 1;
                    const hasLeveledUp = await Levels.appendXp(message.author.id, message.guild.id, randomAmountOfXp);
                    if (hasLeveledUp) {
                        const user = await Levels.fetch(message.author.id, message.guild.id);
                        if (message.guild.me.permissions.has(["SEND_MESSAGES", "READ_MESSAGE_HISTORY", "USE_EXTERNAL_EMOJIS", "EMBED_LINKS"])) {
                            const channel = message.guild.channels.cache.get(data.channel);
                            if (!channel) {
                                return message.channel.send({
                                    embeds: [new MessageEmbed()
                                        .setTitle(`<a:level_up:905751842787569664> LEVEL UP`)
                                        .setDescription(`Congratulations ${message.member}! You have leveled up to **LEVEL ${user.level}** ! <a:level_up_star:905751374711644161>`)
                                        .setColor(ee.color)
                                        .setFooter(client.user.username, client.user.displayAvatarURL())
                                        .setTimestamp()
                                    ]
                                })
                            } else {
                                return channel.send({
                                    embeds: [new MessageEmbed()
                                        .setTitle(`<a:level_up:905751842787569664> LEVEL UP`)
                                        .setDescription(`Congratulations ${message.member}! You have leveled up to **LEVEL ${user.level}** ! <a:level_up_star:905751374711644161>`)
                                        .setColor(ee.color)
                                        .setFooter(client.user.username, client.user.displayAvatarURL())
                                        .setTimestamp()
                                    ]
                                })
                            }
                        } else {
                            return;
                        }
                    }
                } else if (data.toggle == 0) {
    
                }
            })
        } catch (e) {
            console.log(e)
            return message.channel.send({
                embeds: [new MessageEmbed()
                    //.setColor(ee.wrongcolor)
                    .setTitle(`${client.allEmojis.x} ERROR | An error occurred`)
                    //.setFooter(ee.footertext, ee.footericon)
                    .setDescription(`\`\`\`${e.message}\`\`\``)
                ]
            });
        }
    });
    
};


/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Work for Milanio Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Milanio Development, When Using This Code!
 * @INFO
 */
const roleData = require("../models/autorole")

module.exports = function (client, options) {
    const description = {
        name: "AutoRole",
    }
    client.logger(`〢 Module: Loaded ${description.name}`.bold.green);

    client.on("guildMemberAdd", async (member) => {
        if (!member.guild) return;
        try {
            const data = client.autorole.get(member.guild.id);
            if (!data) return;

            let role = data.autorole;
            let arole = member.guild.roles.cache.get(role);
            if (role) {
                member.roles.add(arole).catch(err => console.log(err));
            }
        } catch (e) {
            console.log(e)
        }
    });
}


/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Work for Milanio Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Milanio Development, When Using This Code!
 * @INFO
 */
const Canvas = require("canvas");
const {
  MessageAttachment
} = require("discord.js");

module.exports = function (client, options) {
  const description = {
    name: "WelcomeLeaveSystem",
  }
  client.logger(`〢 Module: Loaded ${description.name}`.bold.green);

  // Welcome System
  client.on("guildMemberAdd", async (member) => {
    if (!member.guild) return;
    try {

      const data1 = client.welcomeLeaveSystem.get(member.guild.id);
      if (!data1) return;

      const canvas = Canvas.createCanvas(1024, 500);

      const ctx = canvas.getContext('2d');

      const background = await Canvas.loadImage(data1.welcome.background);
      ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#f2f2f2';
      ctx.strokeRect();

      var textString3 = `${member.user.tag}`;
      ctx.font = '42px Impact';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(textString3, 512, 410);

      var textString2 = `WELCOME`;
      ctx.font = '72px Impact';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(textString2, 512, 360);
      ctx.beginPath();
      ctx.stroke()
      ctx.arc(512, 166, 128, 0, Math.PI * 2, true);
      ctx.fill()

      var textString4 = `YOU ARE THE ${member.guild.memberCount}TH MEMBER OF OUR SERVER`;
      ctx.textAlign = 'center';
      ctx.font = '32px Impact';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(textString4, 512, 455);
      ctx.beginPath();
      ctx.arc(512, 166, 119, 0, Math.PI * 2, true); //position of img
      ctx.closePath();
      ctx.clip();

      const avatar = await Canvas.loadImage(member.user.displayAvatarURL({
        format: 'jpg',
        size: 1024
      }));

      ctx.drawImage(avatar, 393, 47, 238, 238);

      const attachment = new MessageAttachment(canvas.toBuffer(), `welcome-${member.id}.jpg`);

      const channel = member.guild.channels.cache.get(data1.welcome.channel);
      if (!channel) return;

      await channel.send({
        content: data1.welcome.message.replace(/{user}/g, `${member}`).replace(/{username}/g, `${member.user.username}`).replace(/{server}/g, `${member.guild.name}`).replace(/{membercount}/g, `${member.guild.memberCount}`),
        files: [attachment]
      }).catch(err => console.log('I was unable to send welcome image.'));
    } catch (e) {
      console.log(e)
    }
  });

  // Leave System
  client.on("guildMemberRemove", async (member) => {
    if (!member.guild) return;
    try {

      const data2 = client.welcomeLeaveSystem.get(member.guild.id);
      if (!data2) return;

      const canvas = Canvas.createCanvas(1024, 500);

      const ctx = canvas.getContext('2d');

      const background = await Canvas.loadImage(data2.goodbye.background);
      ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#f2f2f2';
      ctx.strokeRect();

      var textString3 = `${member.user.tag}`;
 
      ctx.font = '42px Impact';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(textString3, 512, 410);
  
      var textString2 = `GOODBYE`;
      ctx.font = '72px Impact';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(textString2, 512, 360);
      ctx.beginPath();
      ctx.stroke()
      ctx.arc(512, 166, 128, 0, Math.PI * 2, true);
      ctx.fill()

      var textString4 = `${member.guild.name}`;
      ctx.textAlign = 'center';
      ctx.font = '32px Impact';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(textString4, 512, 455);

      ctx.beginPath();
      ctx.arc(512, 166, 119, 0, Math.PI * 2, true); 
      ctx.closePath();
      ctx.clip();

      const avatar = await Canvas.loadImage(member.user.displayAvatarURL({
        format: 'jpg',
        size: 1024
      }));

      ctx.drawImage(avatar, 393, 47, 238, 238);

      const attachment = new MessageAttachment(canvas.toBuffer(), `goodbye-${member.id}.jpg`);

      const channel = member.guild.channels.cache.get(data2.goodbye.channel);

      if (!channel) return;

      await channel.send({
        content: data2.goodbye.message.replace(/{user}/g, `${member}`).replace(/{username}/g, `${member.user.username}`).replace(/{server}/g, `${member.guild.name}`).replace(/{membercount}/g, `${member.guild.memberCount}`),
        files: [attachment]
      }).catch(err => console.log('I was unable to send goodbye image.'));

    } catch (e) {
      console.log(e)
    }
  });

};


/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Work for Milanio Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Milanio Development, When Using This Code!
 * @INFO
 */
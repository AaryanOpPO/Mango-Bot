module.exports = async (client, error) => {
  client.logger(String(error).red.dim);
}

/**
 * @INFO
 * Bot Coded by Blind Zedro#2742 | https://discord.gg/fridaydev
 * @INFO
 * Made by Friday Development | https://discord.gg/fridaydev
 * @INFO
 * Please mention us Friday Development, when using this Code!
 * @INFO
 */
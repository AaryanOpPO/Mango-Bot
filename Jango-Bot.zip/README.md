#  Jango Bot

## [**DISCORD SUPPORT SERVER INVITE**](https://discord.gg/xdtcHCSsJ9)
> 💪 **Host on Repit:** [**Repl.it Fork**]([https://replit.com/@BoyNight/Milanio](https://replit.com/@BoyNight/Jango-Bot)

## Installation | How to use the Handler

 **1.** Install [node.js v16+](https://nodejs.org/) or higher

 **2.** Download this repo and unzip it    |    or git clone it

 **3.** Install all of the packages with **`npm install`**     |  the important packages are   **`npm install discord.js enmap`**

 **4** Fill in the parameters, RIGHT in `config.json`!

 **5.** start the bot with **`node bot.js`**!
  
***

## [Discord Server 😎]([https://discord.gg/xdtcHCSsJ9]) | [Website]([https://discord.gg/xdtcHCSsJ9])
<a href="https://dsc.gg/milanio.dev"><img src="https://discord.com/api/guilds/927430661915168770/widget.png?style=banner2"></a>

***

## SUPPORT ME AND SUNDAY DEVELOPMENT

> You can always Support me by inviting one of my **own Discord Bots**

[Mizo Bot](https://discord.com/api/oauth2/authorize?client_id=943761576840798230&permissions=536870911999&scope=bot)| 
[Sound Wave](https://discord.com/api/oauth2/authorize?client_id=943761576840798230&permissions=536870911999&scope=bot)

# Credits

> If consider using this Code, make sure to credit me!
